console.log('euromilhoẽs')
function randint(min, max){
    return Math.floor(Math.random() * (max - min)) + min;  
}
let njogos = 5
for(var c = 1; c<= njogos; c++){
    var numeros = [randint(1,51),randint(1,51), randint(1,51), randint(1,51),randint(1,51), randint(1,51),randint(1,51)]
}